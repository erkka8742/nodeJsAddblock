const express = require('express');
const path = require('path');
const app = express();
const favicon = require('serve-favicon');

app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// You can also set up a route to serve the HTML file via a route, if preferred
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 7001;
app.listen(PORT, () => {
});
