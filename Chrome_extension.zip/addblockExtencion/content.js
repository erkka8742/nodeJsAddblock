console.log("Content script running");

// Function to handle click events
function handleLinkClick(e) {
  let target = e.target;

  // Traverse up the DOM to find the closest link if the target is not the link itself
  while (target && target.tagName.toLowerCase() !== 'a') {
    target = target.parentElement;
  }

  // Now we have the target as the link, check if it's a YouTube video link
  if (target && target.href.includes('watch?v=')) {
    e.preventDefault(); // Prevent the default click action
    e.stopPropagation(); // Stop the event from propagating to other handlers

    // Create the URL for your site with the YouTube video URL as a parameter
    const destinationUrl = `http://localhost:7001?videoUrl=${encodeURIComponent(target.href)}`;

    // Send a message to the background script to open the new URL
    chrome.runtime.sendMessage({ openUrl: destinationUrl });
  }
}

// Add the event listener to the document
document.addEventListener('click', handleLinkClick, true);

// Alternatively, you could use a MutationObserver to re-apply the event listener when new content is loaded
// (You would define a suitable mutation observer to watch for changes in the list of video elements)

  




  